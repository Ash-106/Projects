from prime_generator import get_next_size



class HashTable:
    def __init__(self, collision_type, params):
        '''
        Possible collision_type:
            "Chain"     : Use hashing with chaining
            "Linear"    : Use hashing with linear probing
            "Double"    : Use double hashing
        '''
        
   
    def insert(self, x):
        pass
        
    def find(self, key):
        pass
        
    def get_slot(self, key):
        pass
        

    def get_load(self):
        pass
    
    def __str__(self):
        pass
    
    # TO BE USED IN PART 2 (DYNAMIC HASH TABLE)
    def rehash(self):
        pass
# IMPLEMENT ALL FUNCTIONS FOR CLASSES BELOW
# IF YOU HAVE IMPLEMENTED A FUNCTION IN HashTable ITSELF, 
# YOU WOULD NOT NEED TO WRITE IT TWICE
    
class HashSet(HashTable):
    def __init__(self, collision_type, params):
        self.l = [0]*params[-1]
        self.mul = params[0]
        self.mod = params[-1]
        self.col = collision_type
        self.num_elements = 0
        self.params = params

    def p(self,i):
        if ord(i)-ord('a') < 0:
            return ord(i)-ord('A')+26
        else:
            return ord(i)-ord('a')


    
    def insert(self, key):
        s = self.get_slot(key)
        if self.l[s]!=0:
                    if self.col == "Linear":
                        original_slot = s  # Keep track of where you started
                        while self.l[s] != 0 and self.l[s][0] != key:  # Check for existing key or empty slot
                            s = (s + 1) % self.mod
                            if s == original_slot: 
                                 # Circular check to avoid infinite loop
                                raise Exception("HashTable is full")
                        

                    elif self.col == "Double":
                        dh = 0 
                        var = self.params[2]
                        pol2 = 1
                        mul2 = self.params[1]
                        for i in key:
                            dh += self.p(i)*pol2
                            pol2 *= mul2
                        dh = dh%var
                        var -= dh
                        original_slot = s
                        for i in range(1,self.mod-1):
                            if self.l[s] == 0 or self.l[s] == key:  # Empty slot or matching key
                                break
                            s = (original_slot + i * var) % self.mod
                            if s == original_slot:  
                                raise Exception("HashTable is full")

        if self.col == "Chain":
            if self.l[s]==0:
                self.l[s]=[]
            self.l[s].append(key)
        else:
            self.l[s] = key
        self.num_elements += 1
    
    
    def find(self, key):
        s = self.get_slot(key)
        if self.l[s]!=0:
            if self.col == "Linear":
                original_slot = s  # Keep track of where you started
                while self.l[s] != 0 and self.l[s] != key:  # Check for existing key or empty slot
                    s = (s + 1) % self.mod
                    if s == original_slot:  # Circular check to avoid infinite loop
                        return False

            elif self.col == "Double":
                dh = 0 
                var = self.params[2]
                pol2 = 1
                mul2 = self.params[1]
                for i in key:
                    dh += self.p(i)*pol2
                    pol2 *= mul2
                dh = dh%var
                var -= dh
                original_slot = s
                for i in range(1,self.mod):
                    if self.l[s] == 0:  # Empty slot
                        return False
                    if self.l[s] == key:  # Matching key
                        return self.l[s]
                    s = (original_slot + i * var) % self.mod  # Updated probing logic
                    if s == original_slot :  
                        return False 
                    

        if self.col == "Chain":
            if self.l[s] != 0:
                for k in self.l[s]:
                    if k == key:
                        return True
            return False
        
        else:
            if self.l[s]!=0 and self.l[s] == key:
                return True  # Return the full key-value tuple
            return False
            
    
    def get_slot(self, key):
        s = 0
        pol = 1
        for i in key:
            s += self.p(i)*pol
            pol *= self.mul
        s = s%(self.mod)
        return s
    
    def get_load(self):
        return self.num_elements / len(self.l)
    
    def __str__(self):
        output = []
        
        for bucket in self.l:
            if bucket == 0:
                output.append("<EMPTY>")
            elif isinstance(bucket, list):
                # Filter out unintended empty strings
                elements = [str(item) for item in bucket if item != ""]
                output.append(" ; ".join(elements) if elements else "<EMPTY>")
            else:
                output.append(str(bucket))
        
        return " | ".join(output)
       
class HashMap(HashTable):
    def __init__(self, collision_type, params):
        self.l = [0]*params[-1]
        self.mul = params[0]
        self.mod = params[-1]
        self.col = collision_type
        self.num_elements = 0
        self.params = params
    
    def p(self,i):
        if ord(i)-ord('a') < 0:
            return ord(i)-ord('A')+26
        else:
            return ord(i)-ord('a')


    
    def insert(self, x):
        # x = (key, value)
        s = self.get_slot(x[0])
        key = x[0]
        if self.l[s]!=0:
                    if self.col == "Linear":
                        original_slot = s  # Keep track of where you started
                        while self.l[s] != 0 and self.l[s][0] != key:  # Check for existing key or empty slot
                            s = (s + 1) % self.mod
                            if s == original_slot: 
                                 # Circular check to avoid infinite loop
                                raise Exception("HashTable is full")
                        

                    elif self.col == "Double":
                        dh = 0 
                        var = self.params[2]
                        pol2 = 1
                        mul2 = self.params[1]
                        for i in key:
                            dh += self.p(i)*pol2
                            pol2 *= mul2
                        dh = dh%var
                        var -= dh
                        original_slot = s
                        for i in range(1,self.mod-1):
                            if self.l[s] == 0 or self.l[s][0] == key:  # Empty slot or matching key
                                break
                            s = (original_slot + i * var) % self.mod
                            if s == original_slot:  
                                raise Exception("HashTable is full")

        if self.col == "Chain":
            if self.l[s]==0:
                self.l[s]=[]
            self.l[s].append(x)
        else:
            self.l[s] = x
        self.num_elements += 1
    
    
    def find(self, key):
        s = self.get_slot(key)
        if self.l[s]!=0:
            if self.col == "Linear":
                original_slot = s  # Keep track of where you started
                while self.l[s] != 0 and self.l[s][0] != key:  # Check for existing key or empty slot
                    s = (s + 1) % self.mod
                    if s == original_slot:  # Circular check to avoid infinite loop
                        return False

            elif self.col == "Double":
                dh = 0 
                var = self.params[2]
                pol2 = 1
                mul2 = self.params[1]
                for i in key:
                    dh += self.p(i)*pol2
                    pol2 *= mul2
                dh = dh%var
                var -= dh
                original_slot = s
                for i in range(1,self.mod):
                    if self.l[s] == 0:  # Empty slot
                        return None
                    if self.l[s][0] == key:  # Matching key
                        return self.l[s][1]
                    s = (original_slot + i * var) % self.mod  # Updated probing logic
                    if s == original_slot :  
                        return False 
                    

        if self.col == "Chain":
            if self.l[s] != 0:
                for k in self.l[s]:
                    if k[0] == key:
                        return k[1]
            return None
        
        else:
            if self.l[s]!=0 and self.l[s][0] == key:
                return self.l[s][1]  
            return None
                   
    
    def get_slot(self, key):
        s = 0
        pol = 1
        for i in key:
            s += self.p(i)*pol
            pol *= self.mul
        s = s%(self.mod)
        return s
        
    
    def get_load(self):
        return self.num_elements / len(self.l)
    
    def __str__(self):
        output = []
        
        for bucket in self.l:
            if bucket == 0:
                output.append("<EMPTY>")
            elif isinstance(bucket, list):
                # Filter out unintended empty strings
                elements = [str(item) for item in bucket if item != ""]
                output.append(" ; ".join(elements) if elements else "<EMPTY>")
            else:
                output.append(str(bucket))
        
        return " | ".join(output)
        