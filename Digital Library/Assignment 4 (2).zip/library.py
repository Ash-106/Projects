import hash_table as ht
import dynamic_hash_table as dht
class DigitalLibrary:
    # DO NOT CHANGE FUNCTIONS IN THIS BASE CLASS
    def __init__(self):
        pass
    
    def distinct_words(self, book_title):
        pass
    
    def count_distinct_words(self, book_title):
        pass
    
    def search_keyword(self, keyword):
        pass
    
    def print_books(self):
        pass
    
class MuskLibrary(DigitalLibrary):
    # IMPLEMENT ALL FUNCTIONS HERE
    def __init__(self, book_titles, texts):
        
        
        dupL = []
        for j in texts:
            k=[]
            for i in j:
                k.append(i)
            dupL.append(k)

        for j in range(0,len(dupL)):
            #words = texts[j].split()
            self.mergeSort(dupL[j],0,len(dupL[j]))
        
        self.distword = [0]*len(book_titles)
        self.distl = [[]]*len(book_titles)

        for i in range(0,len(book_titles)):
            self.distl[i] = []

        for i in range(0,len(book_titles)):
            dw = 1
            self.distl[i].append(dupL[i][0])
            for j in range(1,len(dupL[i])):
                if dupL[i][j] != dupL[i][j-1]:
                    self.distl[i].append(dupL[i][j])
                    dw+=1
            self.distword[i] = dw

        self.books = []
        for i in range(0,len(book_titles)):
            self.books.append((book_titles[i],self.distl[i]))
        self.mergeSort(self.books,0,len(self.books))  
        


    def distinct_words(self, book_title):
        st = 0
        en = len(self.books)
        while st <= en:
            mid = (st+en)//2
            if(self.books[mid][0]== book_title):
                return self.books[mid][1]
            elif self.books[mid][0] < book_title:
                st = mid + 1
            else:
                en = mid - 1
    
    def count_distinct_words(self, book_title):
        st = 0
        en = len(self.books)
        while st <= en:
            mid = (st+en)//2
            if(self.books[mid][0]== book_title):
                return len(self.books[mid][1])
            elif self.books[mid][0] < book_title:
                st = mid + 1
            else:
                en = mid - 1
    
    def search_keyword(self, keyword):
        bot = []
        for i in self.books:
            st = 0
            en = len(i[1])-1
            while st <= en:
                mid = (st+en)//2
                if str(i[1][mid]) == keyword:
                    bot.append(i[0])
                    break
                elif str(i[1][mid]) < keyword:
                    st = mid + 1
                else:
                    en = mid - 1    
        return bot           
    
    def print_books(self):
        for book in self.books:
            title, words = book
            print(f"{title}:", end=" ")
            
            # Print each word with separators but without trailing spaces
            for index, word in enumerate(words):
                if index > 0:
                    print(" | ", end="")
                print(word, end="")  
            
            print()
                
            
    def merge(self,arr, l, m, r):
        n1 = m - l + 1
        n2 = r - m
    
        
        L = arr[l:m+1]
        R = arr[m+1:r+1]
    
        
        i = 0     # Initial index of first subarray
        j = 0     # Initial index of second subarray
        k = l     # Initial index of merged subarray
    
        while i < len(L) and j<len(R):
            if L[i] <= R[j]:
                arr[k] = L[i]
                i += 1
            else:
                arr[k] = R[j]
                j += 1
            k += 1
    
        while i < len(L):
            arr[k] = L[i]
            i += 1
            k += 1
    
    
        while j < len(R):
            arr[k] = R[j]
            j += 1
            k += 1
 

 
    def mergeSort(self,arr, l, r):
        if l < r:
    
            m = l+(r-l)//2
    
            # Sort first and second halves
            self.mergeSort(arr, l, m)
            self.mergeSort(arr, m+1, r)
            self.merge(arr, l, m, r)
 
 
# Driver code to test above
class JGBLibrary(DigitalLibrary):
    # IMPLEMENT ALL FUNCTIONS HERE
    def __init__(self, name, params):
        '''
        name    : "Jobs", "Gates" or "Bezos"
        params  : Parameters needed for the Hash Table:
            z is the parameter for polynomial accumulation hash
            Use (mod table_size) for compression function
            
            Jobs    -> (z, initial_table_size)
            Gates   -> (z, initial_table_size)
            Bezos   -> (z1, z2, c2, initial_table_size)
                z1 for first hash function
                z2 for second hash function (step size)
                Compression function for second hash: mod c2
        '''
        if name == "Jobs":
            self.h = ht.HashMap("Chain",params)
        elif name == "Gates":
            self.h = ht.HashMap("Linear",params)
        else:
            self.h = ht.HashMap("Double",params)
        self.name = name
        self.params = params
        self.bookdistwords = []
        
    
    def add_book(self, book_title, text):

        disl = []
        if self.name == "Jobs":
            textset = ht.HashSet("Chain",self.params)
        elif self.name == "Gates":
            textset = ht.HashSet("Linear",self.params)
        else:
            textset= ht.HashSet("Double",self.params)
        for j in text:
            if textset.find(j) == False:
                textset.insert(j)
                
            else:
                continue
         
        for k in textset.l:
            if k!=0:
                if isinstance(k,list):
                    for j in k:
                        if j!=0:
                            disl.append(j)
                else:
                    disl.append(k)

        self.h.insert((book_title,(textset,disl)))
        self.bookdistwords.append((book_title,(textset,disl)))
    
    def distinct_words(self, book_title):
        bookset = self.h.find(book_title) 
        # Retrieve the book's HashSet
        if bookset is not None:
            return bookset[1]

    def count_distinct_words(self, book_title):
        bookset = self.h.find(book_title)
        if bookset!=None:
            return len(bookset[1])
        else:
            return 0
        
    def search_keyword(self, keyword):
        distbooks = []
        for book in self.bookdistwords:
            if book[1][0].find(keyword):
                distbooks.append(book[0])
        return distbooks
            

           
           
    def print_books(self):
        for j in self.bookdistwords:
            if j:
                print(j[0], end=": ")
                c = 0
                if self.name == "Jobs":
                    for k in j[1][0].l:
                        if k:
                            print(" ; ".join(k), end="")
                        else:
                            print("<EMPTY>", end=" ")
                        c += 1
                        if c != len(j[1][0].l):
                            print(" | ", end="")
                else:
                    for k in j[1][0].l:
                        if k:
                            print(k, end="")
                        else:
                            print("<EMPTY>", end=" ")
                        c += 1
                        if c != len(j[1][0].l):
                            print(" | ", end=" ")
                print()

        