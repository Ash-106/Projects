from hash_table import HashSet, HashMap
from prime_generator import get_next_size

class DynamicHashSet(HashSet):
    def __init__(self, collision_type, params):
        super().__init__(collision_type, params)
        
        
    def rehash(self):
        # IMPLEMENT THIS FUNCTION
        new_size = get_next_size() # Get next prime size
        old_table=[]
        for j in self.l:
            old_table.append(j)
        self.l = [0] * new_size
        self.mod = new_size
        self.num_elements = 0
        

        # Reinsert elements into new table
        if self.col == "Chain":
            for entry in old_table:
                if entry != 0:
                    for j in entry:
                        if j!=0:
                            self.insert(j)

        else:
            for entry in old_table:
                if entry != 0:
                    self.insert(entry)

        

    def insert(self, key):
        # YOU DO NOT NEED TO MODIFY THIS
        super().insert(key)
        
        if  self.get_load() >= 0.5:
            self.rehash()
            
            
class DynamicHashMap(HashMap):
    def __init__(self, collision_type, params):
        super().__init__(collision_type, params)
        
        
    def rehash(self):
        # IMPLEMENT THIS FUNCTION
        new_size = get_next_size()  # Get next prime size
        old_table = self.l
        self.l = [0] * new_size
        self.mod = new_size
        self.num_elements = 0

        

        # Reinsert elements into new table
        if self.col == "Chain":
            for entry in old_table:
                if entry != 0:
                    for j in entry:
                        if j!=0:
                            self.insert(j)

        else:
            for entry in old_table:
                if entry != 0:
                    self.insert(entry)
        
        
    def insert(self, key):
        # YOU DO NOT NEED TO MODIFY THIS
        super().insert(key)
        if self.get_load() >= 0.5:
            self.rehash()